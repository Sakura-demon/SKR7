create
    definer = root@localhost procedure GameName_Query(IN Gname varchar(20))
begin
    select Gname,Gimgurl,Gid from Game where Game.Gname = Gname;
end;

