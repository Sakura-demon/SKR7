create
    definer = root@localhost procedure UserMsg(IN Uid int)
begin
    select Uname,Uimgurl from User where User.Uid = Uid;
end;

