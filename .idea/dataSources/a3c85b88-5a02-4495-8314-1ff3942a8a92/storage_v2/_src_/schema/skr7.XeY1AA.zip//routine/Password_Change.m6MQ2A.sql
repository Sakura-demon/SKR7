create
    definer = root@localhost procedure Password_Change(IN Uid int, IN OUpwd varchar(20), IN NUpwd varchar(20), OUT flag int)
begin
    if exists(select * from User where User.Uid = Uid and User.Upwd = OUpwd)
    then
        set flag = 1;
        update User set User.Upwd = NUpwd where User.Uid = Uid;
    else
        set flag = 0;
    end if;
end;

