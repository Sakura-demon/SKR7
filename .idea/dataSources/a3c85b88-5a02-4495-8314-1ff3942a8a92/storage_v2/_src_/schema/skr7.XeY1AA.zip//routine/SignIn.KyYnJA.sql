create
    definer = root@localhost procedure SignIn(IN Uname char(12), IN Upwd varchar(20), OUT flag int)
begin
    if exists(select * from User where User.Uname = Uname and User.Upwd = Upwd)
    then set flag = 1;
    select Uid from User where User.Uname = Uname and User.Upwd = Upwd;
    else
        set flag = 0;
    end if;
end;

