create
    definer = root@localhost procedure Game_Query(IN Gid int, IN flag int)
begin
    if flag = 1 then select Vurl,Vname,Vid from Video where Video.Gid = Gid; end if;
    if flag = 2 then select Purl,Pname,Pid  from Painting where Painting.Gid = Gid;end if;
    if flag = 3 then select GSimgurl,GSname,GSid  from GSetting where GSetting.Gid = Gid;end if;
    if flag = 4 then select GMimgurl,GMname,GMid  from GMusic where GMusic.Gid = Gid;end if;
    if flag = 5 then select GAimgurl,GAname,GAid from GAccessories where GAccessories.Gid = Gid;end if;
end;

