create
    definer = root@localhost procedure GameType_Query(IN Gtype varchar(20))
begin
    select Gname,Gimgurl,Gid from Game where Game.Gtype = Gtype;
end;

