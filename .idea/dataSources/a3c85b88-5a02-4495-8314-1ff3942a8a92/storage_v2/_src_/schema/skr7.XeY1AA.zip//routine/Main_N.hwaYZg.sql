create
    definer = root@localhost procedure Main_N(IN flag int)
begin
    if flag = 1 then select Vurl,Vname,Gid from Video order by Video.Ucount limit 5;end if;
    if flag = 2 then select Purl,Pname,Gid from Painting order by Painting.Ucount limit 5;end if;
    if flag = 3 then select GSimgurl,GSname,Gid from GSetting order by GSetting.Ucount limit 5;end if;
    if flag = 4 then select GMimgurl,GMname,Gid from GMusic order by GMusic.Ucount limit 5;end if;
    if flag = 5 then select GAimgurl,GAname,Gid from GAccessories order by GAccessories.Ucount limit 5;end if;
end;

