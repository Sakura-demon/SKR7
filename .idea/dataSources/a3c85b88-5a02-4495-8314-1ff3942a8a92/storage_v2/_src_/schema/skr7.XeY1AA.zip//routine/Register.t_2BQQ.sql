create
    definer = root@localhost procedure Register(IN Uname char(12), IN Upwd varchar(20), IN Uimgurl varchar(100),
                                                OUT flag int)
begin
    if exists(select * from User where User.Uname = Uname and User.Upwd = Upwd)
    then set flag = 0;
    else
        insert into User(Uname,Upwd,Uimgurl) values(Uname,Upwd,Uimgurl);
        set flag = 1;
        select Uid from User where User.Uname = Uname and User.Upwd = Upwd;
    end if;
end;

