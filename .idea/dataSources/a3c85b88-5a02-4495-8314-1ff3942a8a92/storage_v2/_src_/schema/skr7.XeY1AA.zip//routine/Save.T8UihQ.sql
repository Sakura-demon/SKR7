create
    definer = root@localhost procedure Save(IN Uid int, IN Uimgurl varchar(100), IN NUname varchar(20), OUT flag int)
begin
    update User set User.Uimgurl = Uimgurl,User.Uname = NUname where User.Uid = Uid;
    set flag = 1;
end;

